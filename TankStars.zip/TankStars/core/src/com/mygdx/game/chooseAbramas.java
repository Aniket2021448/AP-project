package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;


public class chooseAbramas implements Screen {
    private tankStars game;
    private OrthographicCamera gameCam;
    private Viewport gamePort;
    private Texture PICK_TANK_ACTIVE;
    private Texture PICK_TANK_INACTIVE;
    private Texture chooseTank;
    private Texture chooseTankBackground1;
    private Texture chooseTankBackground2;
    private Texture logo;
    private Texture abrams;
    private Texture abramsName;
    private Texture goLeft;
    private Texture goRight;
    private Texture goBack;

    private final int Health = 100;
    private Music music;
    private Sound sound;
    private long soundId;

    public chooseAbramas(tankStars game){
        this.game = game;
        gameCam = new OrthographicCamera();
        gamePort = new FitViewport(Gdx.graphics.getWidth(),Gdx.graphics.getHeight(),gameCam);
        gameCam.position.set(((gamePort.getWorldWidth())/2),(gamePort.getWorldHeight()/2),0);


        chooseTankBackground1 = new Texture("images/chooseTankBase.jpg");
        chooseTankBackground2 = new Texture("images/rightSideChooseTank.png");
        PICK_TANK_ACTIVE = new Texture("images/button_lets-rock.png");
        PICK_TANK_INACTIVE = new Texture("images/button_lets-rock_DOWN.png");
        chooseTank = new Texture("images/button_choose-tank.png");
        logo = new Texture("images/Tank_Star_logo.png");

        abrams= new Texture("images/Abramas.png");
        abramsName= new Texture("images/abramasOnChange.png");

        goLeft = new Texture("images/goLeft.png");
        goRight = new Texture("images/goRight.png");
        goBack = new Texture("images/goBack.png");

        music = Gdx.audio.newMusic(Gdx.files.internal("Audio/Background song.mp3"));
        music.setLooping(true);
        music.play();

        sound = Gdx.audio.newSound(Gdx.files.internal("Audio/buttonPressed.mp3"));


    }
    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0,0,0,1);   //Default Base color
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);


        gameCam.update();
        game.batch.setProjectionMatrix(gameCam.combined);
        game.batch.begin();
        game.batch.draw(chooseTankBackground1, 0,0,1200,1080);
        game.batch.draw(chooseTankBackground2,1100,0,820,1080);
        game.batch.draw(logo, 200,Gdx.graphics.getHeight()-400 );


        int NavSize = 200;
        game.batch.draw(goLeft,1110,Gdx.graphics.getHeight()/2-80,NavSize,NavSize);
        game.batch.draw(goRight,Gdx.graphics.getWidth()-200, Gdx.graphics.getHeight()/2-80,NavSize,NavSize);
        game.batch.draw(goBack, 20,Gdx.graphics.getHeight()-150,150,150);

        game.batch.draw(abrams, 270,100, 700,600);
        game.batch.draw(abramsName, 1320, Gdx.graphics.getHeight()/2-100, 400, 200);
        //Changing Tanks and their names on same screen
        //right
        if ((Gdx.input.getX()> 1000  && Gdx.input.getY()> Gdx.graphics.getHeight()/2-80 && Gdx.input.getY()<Gdx.graphics.getHeight()/2-80+200 ) ){
            if (Gdx.input.isTouched() ){
                soundId = sound.play();
                sound.setLooping(soundId,false);

                game.setScreen(new chooseHelio(game));
            }
        }


        //Back
        if (Gdx.input.getX()<150 && Gdx.input.getX()>20 && Gdx.input.getY()<150 && Gdx.input.getY()>40){
            if (Gdx.input.isTouched()){
                soundId = sound.play();
                sound.setLooping(soundId,false);

                game.setScreen(new homeScreen(game));
            }
        }


        int pickWidth, chooseWidth,pickHeight, chooseHeight;
        pickWidth=chooseWidth=400;
        pickHeight= chooseHeight= 100;

        int pickX = Gdx.graphics.getWidth()- 820/2 - pickWidth/2;
        int pickY = 180;
        int chooseX = Gdx.graphics.getWidth()- 820/2 - pickWidth/2;;
        int chooseY = Gdx.graphics.getHeight() - 200 - chooseHeight;

        game.batch.draw(PICK_TANK_ACTIVE, pickX,pickY,pickWidth,pickHeight);
        if (Gdx.input.getX() < pickWidth+pickX && Gdx.input.getX()>pickX && Gdx.graphics.getHeight()-Gdx.input.getY() <  pickY+pickHeight && Gdx.graphics.getHeight()-Gdx.input.getY()>pickY){
            game.batch.draw(PICK_TANK_INACTIVE, pickX,pickY,pickWidth,pickHeight);
            if (Gdx.input.isTouched()){
                soundId = sound.play();
                sound.setLooping(soundId,false);

                game.setScreen(new PlayScreens(game, this));
            }
        }

        game.batch.draw(chooseTank, chooseX,chooseY,chooseWidth,chooseHeight);

        game.batch.end();

    }

    @Override
    public void resize(int width, int height) {
        gamePort.update(width, height);
        gameCam.update();
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        game.batch.dispose();
        abrams.dispose();
        abramsName.dispose();
    }
}


