<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="ShadesOfBrown" tilewidth="8" tileheight="8" tilecount="23375" columns="125">
 <image source="49b015a7b1a305a373aa93346bb67b5f.png" width="1000" height="1500"/>
</tileset>
