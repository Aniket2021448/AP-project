<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="base" tilewidth="16" tileheight="16" tilecount="13398" columns="154">
 <image source="tankStarsRedBase.png" width="2476" height="1396"/>
</tileset>
