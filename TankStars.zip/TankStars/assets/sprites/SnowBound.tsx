<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="SnowBound" tilewidth="8" tileheight="8" tilecount="2500" columns="50">
 <image source="SnowBound.png" width="400" height="400"/>
</tileset>
