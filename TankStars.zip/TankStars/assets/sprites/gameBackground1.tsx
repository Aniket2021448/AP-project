<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="gameBackground1" tilewidth="8" tileheight="8" tilecount="32400" columns="240">
 <image source="gameBackground1.jpg" width="1920" height="1085"/>
</tileset>
